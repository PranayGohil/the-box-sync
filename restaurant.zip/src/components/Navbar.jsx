/**
 * Cinematic Navbar (Bootstrap version)
 * - Appears via GSAP after preloader
 * - Morphs from transparent to glass on scroll
 */
import { useState, useEffect, useRef } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { gsap } from 'gsap';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Sun, Moon, Flame, User } from 'lucide-react';
import { useCart, useTheme } from '../context/AppContext';

const NAV_LINKS = [
  { to: '/',            label: 'Home'    },
  { to: '/menu',        label: 'Menu'    },
  { to: '/reservation', label: 'Reservation' },
  { to: '/about',       label: 'About'   },
  { to: '/contact',     label: 'Contact' },
];

export default function Navbar({ visible }) {
  const [scrolled,    setScrolled]    = useState(false);
  const navRef   = useRef(null);
  const { totalItems } = useCart();
  const { isDark, toggleTheme } = useTheme();
  const location = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  useEffect(() => {
    if (!visible || !navRef.current) return;
    gsap.fromTo(
      navRef.current,
      { y: -60, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.1 }
    );
  }, [visible]);

  if (!visible) return null;

  const navClass = scrolled ? 'py-2 px-3 py-md-3 px-md-4' : 'py-3 px-3 py-md-4 px-md-5';
  const containerClass = scrolled ? 'glass-strong rounded-4 px-3 py-2 px-md-4 py-md-3 shadow' : 'p-0';

  return (
    <>
      <nav
        ref={navRef}
        className={`fixed-top transition-all duration-500 ${navClass}`}
        style={{ opacity: 0, zIndex: 1050 }}
      >
        <div
          className={`container-lg d-flex align-items-center justify-content-between transition-all duration-500 ${containerClass}`}
        >
          {/* Logo */}
          <Link to="/" className="d-flex align-items-center gap-2 gap-md-3 text-decoration-none">
            <div 
              className="rounded-3 d-flex align-items-center justify-content-center shadow-sm"
              style={{ width: '36px', height: '36px', background: 'linear-gradient(135deg, var(--brand), #e05c0c)' }}
            >
              <Flame className="text-white" size={20} />
            </div>
            <span className="font-display fw-bold fs-5 d-none d-sm-block">
              <span className="text-white">Ember</span>
              <span className="text-gradient"> &amp; Gold</span>
            </span>
          </Link>

          {/* Desktop links */}
          <div className="d-none d-md-flex align-items-center gap-4">
            {NAV_LINKS.map(({ to, label }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `nav-link ${isActive ? 'text-brand-400' : 'text-white-60'}`
                }
              >
                {label}
              </NavLink>
            ))}
          </div>

          {/* Actions */}
          <div className="d-flex align-items-center gap-2 gap-md-3">
            <button
              onClick={toggleTheme}
              className="rounded-circle glass d-flex align-items-center justify-content-center border-0"
              style={{ width: '36px', height: '36px', cursor: 'pointer' }}
              aria-label="Toggle theme"
            >
              {isDark
                ? <Sun  size={16} className="text-gold" />
                : <Moon size={16} className="text-brand-400" />
              }
            </button>

            <Link
              to="/cart"
              className="position-relative rounded-circle glass d-flex align-items-center justify-content-center text-decoration-none"
              style={{ width: '36px', height: '36px', cursor: 'pointer' }}
              aria-label="Cart"
            >
              <ShoppingCart size={16} className="text-white" />
              <AnimatePresence>
                {totalItems > 0 && (
                  <motion.span
                    key="badge"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="position-absolute translate-middle badge rounded-pill bg-brand-500"
                    style={{ top: '5px', right: '-15px' }}
                  >
                    {totalItems}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>

            <Link
              to="/profile"
              className="rounded-circle glass d-flex align-items-center justify-content-center text-decoration-none"
              style={{ width: '36px', height: '36px', cursor: 'pointer' }}
              aria-label="Profile"
            >
              <User size={16} className="text-white" />
            </Link>
          </div>
        </div>
      </nav>
    </>
  );
}
