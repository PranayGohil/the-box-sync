import { NavLink } from 'react-router-dom';
import { Home, Info, ShoppingBag, Calendar, Phone } from 'lucide-react';
import { useCart } from '../context/AppContext';
import { motion, AnimatePresence } from 'framer-motion';

export default function MobileBottomNav() {
  const { totalItems } = useCart();

  const NAV_ITEMS = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/about', label: 'About', icon: Info },
    // Center floating item handled separately
    { to: '/reservation', label: 'Book', icon: Calendar },
    { to: '/contact', label: 'Contact', icon: Phone },
  ];

  return (
    <div className="d-md-none fixed-bottom px-3 pb-3" style={{ zIndex: 1050 }}>
      <div 
        className="glass-strong rounded-4 shadow d-flex align-items-center justify-content-between px-2 position-relative"
        style={{ height: '64px' }}
      >
        
        {/* Left Side Items */}
        <div className="d-flex flex-grow-1 justify-content-around align-items-center h-100">
          {NAV_ITEMS.slice(0, 2).map(({ to, label, icon: Icon }) => (
            <NavLink 
              key={to} 
              to={to} 
              className={({ isActive }) => `d-flex flex-column align-items-center justify-content-center text-decoration-none transition-all ${isActive ? 'text-brand-400' : 'text-white-60 hover:text-white'}`}
              style={{ width: '56px', height: '100%' }}
            >
              {({ isActive }) => (
                <>
                  <Icon size={20} className={`mb-1 ${isActive ? 'text-brand-400' : ''}`} style={isActive ? { fill: 'currentColor', fillOpacity: 0.2 } : {}} />
                  <span style={{ fontSize: '10px', fontWeight: 500, letterSpacing: '0.025em' }}>{label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>

        {/* Center Floating Button (Menu) */}
        <div className="position-relative d-flex justify-content-center" style={{ width: '64px', top: '-24px' }}>
          <NavLink 
            to="/menu" 
            className={({ isActive }) => `d-flex flex-column align-items-center justify-content-center rounded-4 text-decoration-none shadow transition-all ${isActive ? 'active' : ''}`}
            style={({ isActive }) => ({
              width: '64px', 
              height: '64px',
              background: isActive 
                ? 'linear-gradient(to bottom right, var(--brand), #e05c0c)' 
                : 'linear-gradient(to bottom right, #f59e42, var(--brand))',
              transform: isActive ? 'scale(0.95)' : 'scale(1)'
            })}
          >
            <ShoppingBag size={24} className="text-white mb-1" />
            <span className="text-white fw-semibold" style={{ fontSize: '10px', letterSpacing: '0.025em' }}>Menu</span>
            
            <AnimatePresence>
              {totalItems > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="position-absolute translate-middle badge rounded-pill border border-white text-dark shadow-sm"
                  style={{ top: '0px', right: '-16px', background: 'var(--gold)', fontSize: '10px' }}
                >
                  {totalItems}
                </motion.span>
              )}
            </AnimatePresence>
          </NavLink>
        </div>

        {/* Right Side Items */}
        <div className="d-flex flex-grow-1 justify-content-around align-items-center h-100">
          {NAV_ITEMS.slice(2, 4).map(({ to, label, icon: Icon }) => (
            <NavLink 
              key={to} 
              to={to} 
              className={({ isActive }) => `d-flex flex-column align-items-center justify-content-center text-decoration-none transition-all ${isActive ? 'text-brand-400' : 'text-white-60 hover:text-white'}`}
              style={{ width: '56px', height: '100%' }}
            >
              {({ isActive }) => (
                <>
                  <Icon size={20} className={`mb-1 ${isActive ? 'text-brand-400' : ''}`} style={isActive ? { fill: 'currentColor', fillOpacity: 0.2 } : {}} />
                  <span style={{ fontSize: '10px', fontWeight: 500, letterSpacing: '0.025em' }}>{label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>
        
      </div>
    </div>
  );
}
