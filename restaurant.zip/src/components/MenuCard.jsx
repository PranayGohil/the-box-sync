import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ShoppingCart, Star, Clock, Flame, Leaf } from 'lucide-react';
import { useCart } from '../context/AppContext';
import toast from 'react-hot-toast';

export default function MenuCard({ item, index = 0 }) {
  const cardRef   = useRef(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);
  const { addItem, items } = useCart();
  const inCart = items.some(i => i.id === item.id);

  const handleMouseMove = (e) => {
    const card = cardRef.current;
    if (!card) return;
    const { left, top, width, height } = card.getBoundingClientRect();
    const x = ((e.clientX - left) / width  - 0.5) * 20;
    const y = ((e.clientY - top)  / height - 0.5) * -20;
    setTilt({ x, y });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setHovered(false);
  };

  const handleAdd = (e) => {
    e.preventDefault();
    addItem(item);
    toast.success(`${item.name} added to cart!`, {
      icon: '🛒',
      style: {
        background: '#1A1A1A',
        color: '#fff',
        border: '1px solid rgba(242,122,26,0.3)',
        borderRadius: '12px',
      },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.07 }}
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
        transition: hovered ? 'transform 0.1s ease' : 'transform 0.5s ease',
      }}
      className="card-3d position-relative h-100"
    >
      {/* Image */}
      <div className="position-relative overflow-hidden" style={{ height: '200px' }}>
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          className="w-100 h-100 object-fit-cover transition-all"
          style={{ transition: 'transform 0.7s' }}
          onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
          onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
        />
        {/* Gradient overlay */}
        <div className="position-absolute bottom-0 start-0 end-0 h-100" style={{ background: 'linear-gradient(to top, rgba(10,10,10,0.8), transparent)' }} />

        {/* Badge */}
        {item.badge && (
          <span className="position-absolute badge bg-brand-500 text-white" style={{ top: '12px', left: '12px' }}>
            {item.badge}
          </span>
        )}

        {/* Veg / Non-veg */}
        <span 
          className="position-absolute rounded-1 d-flex align-items-center justify-content-center"
          style={{ top: '12px', right: '12px', width: '24px', height: '24px', background: item.isVeg ? 'rgba(34, 197, 94, 0.9)' : 'rgba(239, 68, 68, 0.9)' }}
        >
          {item.isVeg
            ? <Leaf size={14} className="text-white" />
            : <Flame size={14} className="text-white" />
          }
        </span>

        {/* Rating */}
        <div className="position-absolute d-flex align-items-center gap-1 glass rounded-pill px-2 py-1" style={{ bottom: '12px', right: '12px' }}>
          <Star size={12} className="text-gold" style={{ fill: 'var(--gold)' }} />
          <span className="text-white fw-semibold" style={{ fontSize: '12px' }}>{item.rating}</span>
        </div>
      </div>

      {/* Body */}
      <div className="p-3 d-flex flex-column" style={{ height: 'calc(100% - 200px)' }}>
        <div className="d-flex align-items-start justify-content-between mb-2">
          <h5 className="font-display fw-semibold text-white mb-0" style={{ lineHeight: 1.2 }}>
            {item.name}
          </h5>
        </div>
        <p className="text-white-60 small mb-3 flex-grow-1" style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {item.description}
        </p>

        {/* Meta row */}
        <div className="d-flex align-items-center gap-2 text-white-60 mb-3" style={{ fontSize: '12px' }}>
          <span className="d-flex align-items-center gap-1">
            <Clock size={12} /> {item.prepTime}
          </span>
          <span>{item.calories} kcal</span>
          <span style={{ color: 'rgba(255,255,255,0.2)' }}>·</span>
          <span>{item.reviews} reviews</span>
        </div>

        {/* Price + Add */}
        <div className="d-flex align-items-center justify-content-between mt-auto">
          <span className="price-tag">${item.price.toFixed(2)}</span>
          <button
            onClick={handleAdd}
            className={`d-flex align-items-center gap-1 btn rounded-pill px-3 py-1 fw-semibold transition-all ${
              inCart
                ? 'text-brand-400'
                : 'bg-brand-500 text-white'
            }`}
            style={{ 
              fontSize: '14px', 
              background: inCart ? 'rgba(242, 122, 26, 0.2)' : undefined,
              border: inCart ? '1px solid rgba(242, 122, 26, 0.4)' : 'none'
            }}
          >
            <ShoppingCart size={14} />
            {inCart ? 'Added' : 'Add'}
          </button>
        </div>
      </div>
    </motion.div>
  );
}
