import { Link } from 'react-router-dom';
import { Flame, MapPin, Phone, Mail } from 'lucide-react';

// Inline social SVG icons (not available in this lucide version)
const InstagramIcon = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-4 h-4"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" stroke="none"/></svg>);
const TwitterIcon  = () => (<svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L2.002 2.25h6.561l4.264 5.637 5.417-5.637Zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>);
const FacebookIcon = () => (<svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M24 12.073C24 5.406 18.627 0 12 0S0 5.406 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.696 4.533-4.696 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.931-1.956 1.886v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>);
const YoutubeIcon  = () => (<svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>);

const FOOTER_LINKS = {
  Explore:  [
    { label: 'Home',    to: '/'       },
    { label: 'Menu',    to: '/menu'   },
    { label: 'About',   to: '/about'  },
    { label: 'Contact', to: '/contact'},
  ],
  'Our Food': [
    { label: 'Pizza',   to: '/menu?cat=pizza'   },
    { label: 'Burgers', to: '/menu?cat=burger'  },
    { label: 'Sushi',   to: '/menu?cat=sushi'   },
    { label: 'Desserts',to: '/menu?cat=dessert' },
  ],
};

const SOCIALS = [
  { Icon: InstagramIcon, href: '#', label: 'Instagram' },
  { Icon: TwitterIcon,   href: '#', label: 'Twitter'   },
  { Icon: FacebookIcon,  href: '#', label: 'Facebook'  },
  { Icon: YoutubeIcon,   href: '#', label: 'YouTube'   },
];

export default function Footer() {
  return (
    <footer className="position-relative mt-5 border-top" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
      {/* Glow top */}
      <div className="position-absolute top-0 start-50 translate-middle-x w-75" style={{ height: '1px', background: 'linear-gradient(90deg, transparent, rgba(242, 122, 26, 0.5), transparent)' }} />

      <div className="container-lg py-5">
        <div className="row g-4">
          {/* Brand */}
          <div className="col-12 col-lg-3">
            <Link to="/" className="d-flex align-items-center gap-2 mb-3 text-decoration-none">
              <div 
                className="rounded-3 d-flex align-items-center justify-content-center shadow-sm"
                style={{ width: '36px', height: '36px', background: 'linear-gradient(135deg, var(--brand), #e05c0c)' }}
              >
                <Flame className="text-white" size={20} />
              </div>
              <span className="font-display fw-bold fs-5">
                <span className="text-white">Ember</span>
                <span className="text-gradient"> &amp; Gold</span>
              </span>
            </Link>
            <p className="text-white-60 small mb-4" style={{ lineHeight: 1.6 }}>
              Fine dining reimagined. Where every dish is crafted with passion and every moment is worth savouring.
            </p>
            {/* Socials */}
            <div className="d-flex gap-2">
              {SOCIALS.map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="rounded-circle glass d-flex align-items-center justify-content-center text-white-60 transition-colors"
                  style={{ width: '36px', height: '36px', textDecoration: 'none' }}
                >
                  <Icon />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(FOOTER_LINKS).map(([title, links]) => (
            <div key={title} className="col-6 col-md-3">
              <h5 className="fw-semibold text-white mb-3">{title}</h5>
              <ul className="list-unstyled d-flex flex-column gap-2">
                {links.map(link => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-white-60 text-decoration-none small transition-colors hover:text-brand-400"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact */}
          <div className="col-12 col-md-3">
            <h5 className="fw-semibold text-white mb-3">Contact</h5>
            <ul className="list-unstyled d-flex flex-column gap-2">
              <li className="d-flex align-items-start gap-2 text-white-60 small">
                <MapPin size={16} className="text-brand-400 flex-shrink-0 mt-1" />
                42 Gourmet Lane, South End, London EC1A 1BB
              </li>
              <li className="d-flex align-items-center gap-2 text-white-60 small">
                <Phone size={16} className="text-brand-400 flex-shrink-0" />
                +44 20 7946 0823
              </li>
              <li className="d-flex align-items-center gap-2 text-white-60 small">
                <Mail size={16} className="text-brand-400 flex-shrink-0" />
                hello@emberandgold.com
              </li>
            </ul>
            <div className="mt-4 glass rounded-3 p-3 text-center">
              <p className="small text-white-60 mb-1">Open Daily</p>
              <p className="fw-semibold text-white mb-0">12:00 PM – 11:00 PM</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-5 pt-4 border-top d-flex flex-column flex-md-row align-items-center justify-content-between gap-3" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
          <p className="small text-white-60 mb-0">
            © {new Date().getFullYear()} Ember &amp; Gold. All rights reserved.
          </p>
          <div className="d-flex gap-4">
            {['Privacy Policy', 'Terms of Service', 'Allergen Info'].map(t => (
              <a key={t} href="#" className="small text-white-60 text-decoration-none transition-colors">
                {t}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
