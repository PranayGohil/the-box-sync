import { useRef } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight, Star } from 'lucide-react';
import { FEATURED_DISHES } from '../data/restaurantData';
import { useCart } from '../context/AppContext';
import toast from 'react-hot-toast';

export default function MenuHighlights() {
  const containerRef = useRef(null);
  const { addItem } = useCart();

  const handleAdd = (item) => {
    addItem(item);
    toast.success(`${item.name} added!`, {
      icon: '🛒',
      style: { background: '#1A1A1A', color: '#fff', border: '1px solid rgba(242,122,26,0.3)', borderRadius: '12px' },
    });
  };

  return (
    <section className="py-5">
      <div className="container-lg">
        <div className="d-flex align-items-center justify-content-between mb-4">
          <h2 className="font-display fs-3 fw-bold text-white mb-0">
            🔥 Today's <span className="text-gradient">Highlights</span>
          </h2>
          <Link to="/menu" className="d-flex align-items-center gap-1 small text-brand-400 text-decoration-none transition-colors hover:text-brand-300">
            See All <ChevronRight size={16} />
          </Link>
        </div>

        <div
          ref={containerRef}
          className="d-flex gap-4 overflow-auto scrollbar-hide pb-3"
        >
          {FEATURED_DISHES.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex-shrink-0 glass rounded-4 overflow-hidden position-relative transition-all"
              style={{ width: '260px' }}
            >
              <div className="position-relative overflow-hidden" style={{ height: '160px' }}>
                <img
                  src={item.image}
                  alt={item.name}
                  loading="lazy"
                  className="w-100 h-100 object-fit-cover transition-all"
                  style={{ transition: 'transform 0.5s' }}
                  onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                  onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
                />
                <div className="position-absolute bottom-0 start-0 end-0" style={{ height: '100%', background: 'linear-gradient(to top, rgba(10,10,10,0.7), transparent)' }} />
                <div className="position-absolute d-flex align-items-center gap-1 glass rounded-pill px-2 py-1" style={{ bottom: '8px', right: '8px' }}>
                  <Star size={12} className="text-gold" style={{ fill: 'var(--gold)' }} />
                  <span className="text-white fw-semibold" style={{ fontSize: '12px' }}>{item.rating}</span>
                </div>
                {item.badge && (
                  <span className="position-absolute badge bg-brand-500 text-white" style={{ top: '8px', left: '8px' }}>{item.badge}</span>
                )}
              </div>

              <div className="p-3">
                <h6 className="fw-semibold text-white mb-1 text-truncate">{item.name}</h6>
                <p className="text-white-60 mb-3" style={{ fontSize: '12px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{item.description}</p>
                <div className="d-flex align-items-center justify-content-between">
                  <span className="text-brand-400 fw-bold">${item.price.toFixed(2)}</span>
                  <button
                    onClick={() => handleAdd(item)}
                    className="btn bg-brand-500 text-white rounded-pill px-3 py-1 fw-medium"
                    style={{ fontSize: '12px' }}
                    onMouseOver={(e) => e.currentTarget.style.opacity = '0.8'}
                    onMouseOut={(e) => e.currentTarget.style.opacity = '1'}
                  >
                    Add +
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
