import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'react-hot-toast';

import { CartProvider, ThemeProvider, AuthProvider } from './context/AppContext';
import Navbar       from './components/Navbar';
import Footer       from './components/Footer';
import Preloader    from './components/Preloader';
import { useLenis } from './hooks/useScroll';

import Home     from './pages/Home';
import MenuPage from './pages/Menu';
import About    from './pages/About';
import Cart     from './pages/Cart';
import Checkout from './pages/Checkout';
import Contact  from './pages/Contact';
import Reservation from './pages/Reservation';
import Profile     from './pages/Profile';
import Rewards     from './pages/Rewards';
import Reorder     from './pages/Reorder';
import MobileBottomNav from './components/MobileBottomNav';

/* ─── Page transition wrapper ─── */
const pageVariants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' } },
  exit:    { opacity: 0, y: -8, transition: { duration: 0.25 } },
};

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div key={location.pathname} variants={pageVariants} initial="initial" animate="animate" exit="exit">
        <Routes location={location}>
          <Route path="/"            element={<Home />}     />
          <Route path="/menu"        element={<MenuPage />} />
          <Route path="/about"       element={<About />}    />
          <Route path="/cart"        element={<Cart />}     />
          <Route path="/checkout"    element={<Checkout />} />
          <Route path="/contact"     element={<Contact />}  />
          <Route path="/reservation" element={<Reservation />} />
          <Route path="/profile"     element={<Profile />}  />
          <Route path="/rewards"     element={<Rewards />}  />
          <Route path="/reorder"     element={<Reorder />}  />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
}

function AppShell() {
  const [loading, setLoading] = useState(true);
  const [navVisible, setNavVisible] = useState(false);
  useLenis(); // Initialize smooth scroll

  const handlePreloaderComplete = () => {
    setLoading(false);
    setNavVisible(true);
  };

  return (
    <div className="pb-28 md:pb-0"> {/* Padding for mobile bottom nav */}
      <AnimatePresence>
        {loading && <Preloader onComplete={handlePreloaderComplete} />}
      </AnimatePresence>

      <Navbar visible={navVisible} />
      <AnimatedRoutes />
      <Footer />
      <MobileBottomNav />

      {/* Global Toast Notifications */}
      <Toaster 
        position="bottom-right" 
        toastOptions={{
          style: {
            background: '#1A1A1A',
            color: '#fff',
            border: '1px solid rgba(242,122,26,0.3)',
            borderRadius: '12px'
          }
        }} 
      />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <CartProvider>
            <AppShell />
          </CartProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
