import { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { useGSAPReveal } from '../hooks/useScroll';
import { useRef } from 'react';

// Inline social SVG icons
const InstagramIcon = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} width="20" height="20"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" stroke="none"/></svg>);
const TwitterIcon  = () => (<svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L2.002 2.25h6.561l4.264 5.637 5.417-5.637Zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>);
const FacebookIcon = () => (<svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M24 12.073C24 5.406 18.627 0 12 0S0 5.406 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.696 4.533-4.696 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.931-1.956 1.886v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>);

const CONTACT_INFO = [
  { Icon: MapPin, label: 'Address',       value: '42 Gourmet Lane, South End, London EC1A 1BB' },
  { Icon: Phone,  label: 'Reservations',  value: '+44 20 7946 0823' },
  { Icon: Mail,   label: 'Email',         value: 'hello@emberandgold.com' },
  { Icon: Clock,  label: 'Opening Hours', value: 'Daily: 12:00 PM – 11:00 PM' },
];

const SOCIALS = [
  { Icon: InstagramIcon, href: '#', label: 'Instagram' },
  { Icon: TwitterIcon,   href: '#', label: 'Twitter'   },
  { Icon: FacebookIcon,  href: '#', label: 'Facebook'  },
];

function Field({ label, id, error, as = 'input', ...props }) {
  const cls = `input-field w-100 ${error ? 'border-danger' : ''}`;
  return (
    <div className="mb-3">
      <label htmlFor={id} className="form-label small text-white-60 mb-1">{label}</label>
      {as === 'textarea'
        ? <textarea id={id} className={`${cls}`} style={{ resize: 'none' }} {...props} />
        : <input    id={id} className={cls} {...props} />
      }
      {error && <p className="small text-danger mt-1 mb-0">{error.message}</p>}
    </div>
  );
}

export default function Contact() {
  const [sent, setSent] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm();
  const containerRef = useRef(null);
  useGSAPReveal(containerRef);

  const onSubmit = async () => {
    await new Promise(r => setTimeout(r, 1200));
    setSent(true);
    reset();
    toast.success('Message sent! We\'ll be in touch soon.', {
      style: { background: '#1A1A1A', color: '#fff', border: '1px solid rgba(242,122,26,0.3)', borderRadius: '12px' },
    });
  };

  return (
    <main ref={containerRef} className="min-vh-100 overflow-hidden" style={{ paddingTop: '8rem', paddingBottom: '6rem' }}>
      <div className="container-lg" style={{ maxWidth: '1140px' }}>
        {/* Header */}
        <div data-reveal="bottom" className="text-center mb-5">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <p className="section-subtitle mb-2">Get in Touch</p>
            <h1 className="section-title text-white">
              We'd Love to <span className="text-gradient">Hear From You</span>
            </h1>
            <p className="text-white-60 mt-3 mx-auto" style={{ maxWidth: '36rem' }}>
              Whether you're booking a table, asking about our menu, or just want to say hello — reach out and we'll respond promptly.
            </p>
          </motion.div>
        </div>

        <div className="row g-5">
          {/* Left — Info */}
          <div className="col-12 col-lg-6" data-reveal="left">
            <div className="d-flex flex-column gap-3 mb-5">
              {CONTACT_INFO.map(({ Icon, label, value }) => (
                <div key={label} className="d-flex gap-3 glass rounded-4 p-3 align-items-start">
                  <div className="rounded-3 d-flex align-items-center justify-content-center flex-shrink-0" style={{ width: '40px', height: '40px', background: 'rgba(242, 122, 26, 0.1)', border: '1px solid rgba(242, 122, 26, 0.2)' }}>
                    <Icon size={20} className="text-brand-400" />
                  </div>
                  <div>
                    <p className="small text-white-60 mb-0" style={{ fontSize: '12px' }}>{label}</p>
                    <p className="text-white small fw-medium mb-0">{value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Socials */}
            <div className="mb-5">
              <p className="small text-white-60 mb-3">Follow our story</p>
              <div className="d-flex gap-3">
                {SOCIALS.map(({ Icon, href, label }) => (
                  <a
                    key={label}
                    href={href}
                    aria-label={label}
                    className="rounded-circle glass d-flex align-items-center justify-content-center text-white-60 transition-colors hover:text-brand-400"
                    style={{ width: '40px', height: '40px' }}
                  >
                    <Icon />
                  </a>
                ))}
              </div>
            </div>

            {/* Google Map Embed */}
            <div className="rounded-4 overflow-hidden border" style={{ height: '224px', borderColor: 'rgba(255,255,255,0.1)' }}>
              <iframe
                title="Restaurant location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.8853555553397!2d-0.09997578422955879!3d51.5203701795978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761ca65b0a38bb%3A0x42f36e7d3e7b9e0!2sCity%20of%20London!5e0!3m2!1sen!2suk!4v1614000000000!5m2!1sen!2suk"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg)' }}
                allowFullScreen
                loading="lazy"
              />
            </div>
          </div>

          {/* Right — Form */}
          <div className="col-12 col-lg-6" data-reveal="right">
            <div className="glass rounded-4 p-4 p-md-5 h-100">
              {sent ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="d-flex flex-column align-items-center justify-content-center text-center py-5 h-100"
                >
                  <CheckCircle size={64} className="text-success mb-4" />
                  <h3 className="fw-semibold text-white mb-2">Message Sent!</h3>
                  <p className="text-white-60 mb-4">We'll get back to you within 24 hours.</p>
                  <button onClick={() => setSent(false)} className="btn-ghost">
                    Send Another
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} noValidate className="d-flex flex-column gap-3 h-100">
                  <h4 className="fw-semibold text-white mb-4">Send Us a Message</h4>

                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <Field label="Full Name" id="name" placeholder="Your name" error={errors.name}
                        {...register('name', { required: 'Name is required' })} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <Field label="Email" id="contactEmail" placeholder="you@example.com" type="email" error={errors.contactEmail}
                        {...register('contactEmail', {
                          required: 'Email is required',
                          pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email' },
                        })} />
                    </div>
                  </div>

                  <Field label="Subject" id="subject" placeholder="How can we help?" error={errors.subject}
                    {...register('subject', { required: 'Subject is required' })} />

                  <Field label="Message" id="message" as="textarea" rows={5} placeholder="Tell us more..." error={errors.message}
                    {...register('message', { required: 'Message is required', minLength: { value: 20, message: 'At least 20 characters' } })} />

                  <button type="submit" disabled={isSubmitting} className="btn-primary w-100 justify-content-center mt-auto" style={{ opacity: isSubmitting ? 0.6 : 1 }}>
                    {isSubmitting ? (
                      <>
                        <div className="spinner-border spinner-border-sm me-2" role="status">
                          <span className="visually-hidden">Loading...</span>
                        </div>
                        Sending...
                      </>
                    ) : (
                      <><Send size={20} className="me-2" /> Send Message</>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
