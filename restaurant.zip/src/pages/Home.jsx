import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Play, ArrowRight, Star } from 'lucide-react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import HeroScene from '../components/HeroScene';
import MenuHighlights from '../components/MenuHighlights';
import { CATEGORIES, TESTIMONIALS } from '../data/restaurantData';
import { useGSAPReveal } from '../hooks/useScroll';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const containerRef = useRef(null);
  useGSAPReveal(containerRef);

  return (
    <div ref={containerRef} className="overflow-hidden">
      {/* ── HERO SECTION ── */}
      <section className="position-relative w-100 min-vh-100 d-flex align-items-center justify-content-center overflow-hidden">
        {/* 3D Scene Background */}
        <div className="position-absolute top-0 bottom-0 start-0 end-0" style={{ zIndex: 0 }}>
          <HeroScene />
        </div>
        
        {/* Vignette Overlay */}
        <div className="position-absolute top-0 bottom-0 start-0 end-0 pointer-events-none opacity-75" style={{ background: 'radial-gradient(ellipse at center, transparent 0%, #060606 100%)', zIndex: 0 }} />
        <div className="position-absolute top-0 bottom-0 start-0 end-0 pointer-events-none" style={{ background: 'linear-gradient(to bottom, rgba(10,10,10,0.4), transparent, #0A0A0A)', zIndex: 0 }} />

        <div className="position-relative container-lg w-100 d-flex flex-column align-items-center text-center mt-5" style={{ zIndex: 10 }}>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: "easeOut", delay: 3.2 }}
            className="d-inline-flex align-items-center gap-2 px-3 py-2 rounded-pill glass mb-4"
          >
            <span className="rounded-circle bg-brand-500" style={{ width: '8px', height: '8px', animation: 'pulse 2s infinite' }} />
            <span className="small fw-medium text-uppercase" style={{ letterSpacing: '0.05em', color: '#fcd3b6' }}>Michelin Star Experience</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 3.4 }}
            className="font-display fw-bold mb-4"
            style={{ fontSize: 'clamp(3rem, 8vw, 6rem)', lineHeight: 1.1 }}
          >
            A Symphony of <br/>
            <span className="text-gradient fst-italic">Flavours</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 3.7 }}
            className="fs-5 text-white-60 mb-5 fw-light"
            style={{ maxWidth: '42rem' }}
          >
            Experience culinary artistry where every dish tells a story. 
            Immerse yourself in a world of taste, crafted with passion.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 4 }}
            className="d-flex flex-column flex-sm-row align-items-center gap-4"
          >
            <Link to="/menu" className="btn-primary" style={{ width: '100%', minWidth: '200px' }}>
              Explore Menu
            </Link>
            
            <Link to="/reservation" className="btn-ghost" style={{ width: '100%', minWidth: '200px' }}>
              Book Table
            </Link>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4.5, duration: 1 }}
          className="position-absolute start-50 translate-middle-x d-flex flex-column align-items-center gap-2"
          style={{ bottom: '2.5rem' }}
        >
          <span className="small text-white-60 text-uppercase" style={{ letterSpacing: '0.3em', fontSize: '10px' }}>Scroll</span>
          <div className="overflow-hidden" style={{ width: '1px', height: '48px', background: 'rgba(255,255,255,0.1)' }}>
            <div className="w-100 h-50 bg-brand-500" style={{ animation: 'scrollDown 1.5s infinite' }} />
          </div>
        </motion.div>
      </section>

      {/* ── HIGHLIGHTS STRIP ── */}
      <div data-reveal="bottom" className="position-relative" style={{ zIndex: 10, marginTop: '-5rem' }}>
         <MenuHighlights />
      </div>

      {/* ── TESTIMONIALS ── */}
      <section className="py-5 bg-dark-800" style={{ paddingBottom: '6rem' }}>
        <div className="container-lg py-5">
          <div className="text-center mb-5" data-reveal="bottom">
            <h2 className="section-title mb-3">
              Voices of <span className="text-gradient">Delight</span>
            </h2>
          </div>
          <div className="row g-4">
            {TESTIMONIALS.slice(0, 3).map((t, i) => (
              <div key={t.id} className="col-12 col-md-4">
                <div data-reveal="bottom" data-delay={i * 0.15} className="glass p-4 rounded-4 position-relative h-100">
                  <div className="d-flex gap-1 mb-4">
                    {[...Array(t.rating)].map((_, idx) => (
                      <Star key={idx} size={16} className="text-gold" style={{ fill: 'var(--gold)' }} />
                    ))}
                  </div>
                  <p className="text-white-60 fst-italic mb-4">"{t.text}"</p>
                  <div className="d-flex align-items-center gap-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center fw-bold text-brand-400"
                      style={{ width: '48px', height: '48px', background: 'rgba(242, 122, 26, 0.1)' }}
                    >
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <h6 className="fw-bold text-white mb-0">{t.name}</h6>
                      <small className="text-white-60">{t.role}</small>
                    </div>
                  </div>
                  {/* Large quote mark */}
                  <div className="position-absolute font-display pointer-events-none" style={{ top: '1rem', right: '1.5rem', fontSize: '4rem', color: 'rgba(255,255,255,0.05)', lineHeight: 1 }}>"</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: .5; }
        }
        @keyframes scrollDown {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(200%); }
        }
      `}</style>
    </div>
  );
}
