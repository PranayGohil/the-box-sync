import { useState, useMemo, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { MENU_ITEMS, CATEGORIES } from '../data/restaurantData';
import MenuCard from '../components/MenuCard';
import { useGSAPReveal } from '../hooks/useScroll';

export default function MenuPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search,    setSearch]    = useState('');
  const [activeTab, setActiveTab] = useState(searchParams.get('cat') || 'all');
  const [vegFilter, setVegFilter] = useState('all'); // 'all' | 'veg' | 'nonveg'
  const [sortBy,    setSortBy]    = useState('popular'); // 'popular' | 'price-asc' | 'price-desc' | 'rating'
  const [showFilters, setShowFilters] = useState(false);
  const containerRef = useRef(null);

  useGSAPReveal(containerRef);

  const handleTab = (id) => {
    setActiveTab(id);
    setSearchParams(id !== 'all' ? { cat: id } : {});
  };

  const filtered = useMemo(() => {
    let items = MENU_ITEMS;

    // Category
    if (activeTab !== 'all') items = items.filter(i => i.category === activeTab);

    // Veg
    if (vegFilter === 'veg')    items = items.filter(i => i.isVeg);
    if (vegFilter === 'nonveg') items = items.filter(i => !i.isVeg);

    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(i =>
        i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q)
      );
    }

    // Sort
    switch (sortBy) {
      case 'price-asc':  return [...items].sort((a, b) => a.price - b.price);
      case 'price-desc': return [...items].sort((a, b) => b.price - a.price);
      case 'rating':     return [...items].sort((a, b) => b.rating - a.rating);
      default:           return [...items].sort((a, b) => b.reviews - a.reviews);
    }
  }, [activeTab, vegFilter, search, sortBy]);

  return (
    <main ref={containerRef} className="min-vh-100 overflow-hidden" style={{ paddingTop: '8rem', paddingBottom: '6rem' }}>
      {/* Page Header */}
      <div data-reveal="bottom" className="container-lg mb-5 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <p className="section-subtitle mb-2">Explore Our</p>
          <h1 className="section-title text-white">
            Full <span className="text-gradient">Menu</span>
          </h1>
          <p className="text-white-60 mt-3 mx-auto" style={{ maxWidth: '36rem' }}>
            Every dish is crafted to perfection. Filter, search, and discover your next favourite.
          </p>
        </motion.div>
      </div>

      <div className="container-lg">
        {/* Search + Filter Toggle */}
        <div data-reveal="bottom" data-delay="0.1" className="d-flex gap-3 mb-4">
          <div className="flex-grow-1 position-relative">
            <Search className="position-absolute text-white-60" size={16} style={{ top: '50%', left: '1rem', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              id="menu-search"
              placeholder="Search dishes..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-field w-100"
              style={{ paddingLeft: '2.5rem' }}
            />
            {search && (
              <button onClick={() => setSearch('')} className="position-absolute btn p-0 text-white-60 border-0" style={{ top: '50%', right: '1rem', transform: 'translateY(-50%)' }}>
                <X size={16} className="text-white-60" />
              </button>
            )}
          </div>
          <button
            onClick={() => setShowFilters(v => !v)}
            className={`btn glass d-flex align-items-center gap-2 px-3 py-2 ${showFilters ? 'text-brand-400 border-brand-400' : 'text-white-60'}`}
          >
            <SlidersHorizontal size={16} />
            <span className="d-none d-sm-inline">Filters</span>
          </button>
        </div>

        {/* Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mb-4"
            >
              <div className="glass rounded-4 p-4 d-flex flex-column flex-sm-row gap-4">
                {/* Diet */}
                <div>
                  <label className="small text-white-60 text-uppercase d-block mb-2" style={{ letterSpacing: '0.05em' }}>Diet</label>
                  <div className="d-flex gap-2">
                    {[['all', 'All'], ['veg', 'Veg'], ['nonveg', 'Non-Veg']].map(([val, label]) => (
                      <button
                        key={val}
                        onClick={() => setVegFilter(val)}
                        className={`btn rounded-pill px-3 py-1 small ${vegFilter === val ? 'bg-brand-500 text-white border-0' : 'glass text-white-60 border-0'}`}
                        style={{ fontSize: '14px' }}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sort */}
                <div>
                  <label className="small text-white-60 text-uppercase d-block mb-2" style={{ letterSpacing: '0.05em' }}>Sort By</label>
                  <div className="d-flex gap-2 flex-wrap">
                    {[
                      ['popular',    'Most Popular'],
                      ['rating',     'Highest Rated'],
                      ['price-asc',  'Price: Low–High'],
                      ['price-desc', 'Price: High–Low'],
                    ].map(([val, label]) => (
                      <button
                        key={val}
                        onClick={() => setSortBy(val)}
                        className={`btn rounded-pill px-3 py-1 small ${sortBy === val ? 'bg-brand-500 text-white border-0' : 'glass text-white-60 border-0'}`}
                        style={{ fontSize: '14px' }}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Category Tabs */}
        <div data-reveal="bottom" data-delay="0.2" className="d-flex gap-2 overflow-auto scrollbar-hide mb-4 pb-2">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => handleTab(cat.id)}
              className={`btn rounded-pill px-4 py-2 d-flex align-items-center gap-2 text-nowrap transition-all ${
                activeTab === cat.id
                  ? 'bg-brand-500 text-white shadow-brand border-0'
                  : 'glass text-white-60 border-0 hover:text-white'
              }`}
            >
              <span>{cat.icon}</span> {cat.label}
            </button>
          ))}
        </div>

        {/* Results Count */}
        <div data-reveal="bottom" data-delay="0.3" className="mb-4">
          <p className="text-white-60 small mb-0">
            {filtered.length} dish{filtered.length !== 1 ? 'es' : ''} found
          </p>
        </div>

        {/* Grid */}
        <AnimatePresence mode="wait">
          {filtered.length > 0 ? (
            <motion.div
              key={`${activeTab}-${vegFilter}-${sortBy}-${search}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="row g-4"
            >
              {filtered.map((item, i) => (
                <div key={item.id} className="col-12 col-sm-6 col-lg-4 col-xl-3">
                  <MenuCard item={item} index={i} />
                </div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="d-flex flex-column align-items-center justify-content-center text-center"
              style={{ padding: '6rem 0' }}
            >
              <span className="mb-3" style={{ fontSize: '4rem' }}>🍽️</span>
              <h4 className="fw-semibold text-white mb-2">No dishes found</h4>
              <p className="text-white-60 mb-4">Try adjusting your search or filters.</p>
              <button
                onClick={() => { setSearch(''); setActiveTab('all'); setVegFilter('all'); }}
                className="btn-ghost"
              >
                Clear Filters
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </main>
  );
}
